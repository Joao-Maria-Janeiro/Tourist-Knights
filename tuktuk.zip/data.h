#ifndef _DATA_H
#define _DATA_H

#include "structs.h"

void readFromFile(char * );
void allocatePoints(Map * , int , int , char , int );
void allocateMap(Map * , int , int );
int verifyMap(int , int , char , int );
void printMap(Map* , int);
void freeMap(Map*, int);
void allocateMap(Map * , int , int );
int verifyPoints(Map *, int);

#endif
